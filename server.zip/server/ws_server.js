//Websocket server
var WebSocketServer = require('ws').Server
    , wss = new WebSocketServer({port: 8080});
console.log("My socket server is running");

const ADMIN_PASSWORD = "trueloginadmin123";


//Global variables
var connectedClients = [];
var adminClients = [];

wss.on('connection', function(ws) {
    ws.id =  Math.random().toString(36).substr(2, 9);
    ws.on('close', function() {
        //console.log('disconnected');
        try {
            //Remove client from connected clients
            let client_index = connectedClients.findIndex(x => x.client_id == ws.id);
            console.log("removing client: " + connectedClients[client_index].uuid);
            connectedClients.splice(client_index, 1);
            //sendStatusToAdmins();
        } catch (error) {
            //console.log("Error setting client status to offline");
        }
        
    });

    ws.on('message', function(message) {
        if(message == "admin:" + ADMIN_PASSWORD) {
            adminClients.push(ws);
            let data = { type: "auth", status: "success" };
            ws.send(JSON.stringify(data));
            //sendStatusToAdmins();
        } else {
            let client_message = JSON.parse(message);
            switch(client_message.type) {
                case "register":
                    let info = {
                        client_id : ws.id,
                        ip: ws._socket.remoteAddress, 
                        uuid: client_message.data.uuid,
                        data : client_message.data,
                        ws : ws
                    }
                    registerClient(info);
                    break;
                case "job_output":
                    sendJobOutputToAdmins(client_message.data);
                    break;
                case "admin_job":
                    //console.log(client_message);
                    adminJob(client_message.job_data, client_message.uuid);
                    break;
            }
        }
    });
});

function adminJob(data, uuid) {
    let client_index = connectedClients.findIndex(x => x.uuid == uuid);
    if(client_index != -1) {
        let client = connectedClients[client_index];
        client.ws.send(JSON.stringify(data));
    }
}

function sendJobOutputToAdmins(data) {
    //console.log(data)
    adminClients.forEach(function(admin_client) {
        let message = { type: "job_output", data: data };
        console.log(message);
        admin_client.send(JSON.stringify(message));
    });
}

function sendStatusToAdmins() {
    adminClients.forEach(function(admin_client) {
        let data = { type: "status", clients: {count: connectedClients.length, data: connectedClients} };
        admin_client.send(JSON.stringify(data));
    });
}

function registerClient(data) {
    let client_index = connectedClients.findIndex(x => x.uuid == data.uuid);
    if(client_index == -1) {
        connectedClients.push(data);
        console.log("New client registered: " + data.uuid);
        //sendStatusToAdmins();
    } 
}

setInterval(sendStatusToAdmins, 5000);

// setInterval(()=> {
//     console.log(connectedClients);
// }, 1000)